<!-- koneksi database-->
<?php
$koneksi = new mysqli('localhost', 'root', '', 'online_shop');
?>