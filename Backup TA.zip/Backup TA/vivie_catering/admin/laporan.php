<h1>Laporan Penjualan</h1>
<!-- table -->
<?php
$tglm = '-';
$tgls = '-';
$semuadata = array();
if (isset($_POST['cari'])) {
    $tglm = $_POST['tglm'];
    $tgls = $_POST['tgls'];
    $ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.
    id_pelanggan = pelanggan.id_pelanggan 
    WHERE ((tanggal_pembelian BETWEEN '$tglm' AND '$tgls') AND status_pembayaran != 'pending')");

    while ($pecah = $ambil->fetch_assoc()) {
        $semuadata[] = $pecah;
    }
    // echo "<pre>";
    // print_r($semuadata);
    // echo "</pre>";
}
?>
<div class="card shadow mb-4">

    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan pembelian dari <?= $tglm ?> sampai <?= $tgls ?></h6>
    </div>
    </form>
    <div class="card-body">
        <form action="" method="POST" class="jangan">
            <div class="row mx-auto">
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="">Tanggal mulai</label>
                        <input type="date" class="form-control" name="tglm">
                    </div>

                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="">Tanggal selesai</label>
                        <input type="date" class="form-control" name="tgls">
                    </div>
                </div>
                <div class="col-md-1">
                    <label for="">&nbsp;</label> <br>
                    <button type="submit" class="btn btn-primary" name="cari">Lihat</button>
                </div>
                <div class="col-md-1">
                    <label for="">&nbsp;</label> <br>
                    <a onclick="window.print()" class="btn btn-secondary">Print</a>
                </div>
            </div>
        </form>
        <div id="cetak " class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($semuadata as $key => $data) :
                    ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['nama'] ?></td>
                            <td><?= $data['tanggal_pembelian'] ?></td>
                            <td>Rp. <?= number_format($data['total_harga'])  ?></td>
                            <td><?= $data['status_pembayaran'] ?></td>
                        </tr>
                    <?php $no++;
                    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>