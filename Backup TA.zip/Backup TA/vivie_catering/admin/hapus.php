<?php
include '../koneksi.php';
$id = $_POST['id_prod'];
$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk = '$id'");
$data = $ambil->fetch_assoc();
$fotoproduk = $data['foto_produk'];
if (file_exists("../assets/images/produk/$fotoproduk")) {
    unlink("../assets/images/produk/$fotoproduk");
}

$koneksi->query("DELETE FROM produk WHERE id_produk = '$id'");
echo "<meta http-equiv= 'refresh' content='1;url=index.php?halaman=produk'>";
